<?php
    $server = "localhost:3306";
    $username = "peneliti_sukri";
    $password = "@QazXsw21";
    $database = "peneliti_wattMeter";

    $mysqli = mysqli_connect($server, $username, $password, $database);
?>